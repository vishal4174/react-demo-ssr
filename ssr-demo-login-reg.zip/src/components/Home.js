import React from "react";
import "../App.css";
import img from "../demo.png";

const Home = () => {
  return (
    <div className="container">
      <img src={img} style={{ width: "100%" }}></img>
      <div className="centered">
        <button
          className="btn btn-danger text-white"
          style={{
            padding: "20px 40px 20px 40px ",
            borderRadius: "25px",
            margin: "10px",
          }}
        >
          <a href="/login" style={{ color: "white" }}>
            Login
          </a>
        </button>
        <button
          className="btn btn-danger text-white"
          style={{
            padding: "20px 40px 20px 40px ",
            borderRadius: "25px",
            margin: "10px",
          }}
        >
          <a href="/register" style={{ color: "white" }}>
            Registarion
          </a>
        </button>
      </div>
    </div>
  );
};

export default Home;
