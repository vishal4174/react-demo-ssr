import React from "react";
import "./App.css";
import Login from "./components/Login";
import { Register } from "./components/Register";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Protected from "./Protected";
import Navbar from "./components/Navbar";
import Table from "./components/Table";
import UseID from "./components/UseID";
import Batching from "./components/Batching";
import Transition from "./components/Transition";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/table" element={<Protected Component={Table} />} />
          <Route path="/useID" element={<Protected Component={UseID} />} />
          <Route
            path="/batching"
            element={<Protected Component={Batching} />}
          />
          <Route
            path="/transition"
            element={<Protected Component={Transition} />}
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
